﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConvertNumbToBool
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Convert.ToBoolean(0));
            Console.WriteLine(Convert.ToBoolean(1));
            Console.WriteLine(Convert.ToBoolean(5000));
            Console.ReadKey();
        }
    }
}
